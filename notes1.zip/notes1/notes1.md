# Development Tools Notes

## What is Markdown?

**Markdown** is a lightweight markup language created by John Gruber in 2004. It allows you to format text using simple, plain-text syntax that can be easily converted to HTML. Markdown is widely used for:

- Documentation files (README.md)
- Blog posts and articles
- Forum discussions
- Technical documentation
- Note-taking

*Key features:* Simple syntax, platform-independent, human-readable even in raw form.

## What is Git?

**Git** is a distributed version control system created by Linus Torvalds in 2005. It helps developers:

- Track changes in source code
- Collaborate with other developers
- Maintain history of project changes
- Branch and merge code easily

*Main concepts:*
- Repository: Storage for project files and history
- Commit: Snapshot of changes at a specific time
- Branch: Separate line of development
- Merge: Combining changes from different branches

## What is GitHub?

**GitHub** is a web-based platform that provides Git repository hosting and collaboration features. It offers:

- Cloud storage for Git repositories
- Pull requests for code review
- Issue tracking and project management
- Collaboration tools for teams
- GitHub Pages for hosting websites

*Key features:* Social coding, open source community, CI/CD integration, and extensive third-party integrations.

## What is Slack?

**Slack** is a cloud-based team collaboration platform that provides:

- Real-time messaging and communication
- Channel-based organization
- File sharing and integration with other tools
- Video and voice calls
- Searchable message history

*Common uses:*
- Team communication and coordination
- Project discussions in dedicated channels
- Integration with development tools (GitHub, JIRA, etc.)
- Quick decision-making and problem-solving